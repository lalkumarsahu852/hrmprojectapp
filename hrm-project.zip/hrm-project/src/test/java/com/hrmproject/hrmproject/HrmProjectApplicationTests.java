package com.hrmproject.hrmproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrmProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
